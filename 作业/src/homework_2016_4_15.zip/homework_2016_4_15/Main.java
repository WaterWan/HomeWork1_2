package homework_2016_4_15;

public class Main {
	public static void main(String[] args) {
		CourseTest ct = new CourseTest();
	}
}
