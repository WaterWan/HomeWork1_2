package homework_2016_4_15;

public class CourseTest {
	public CourseTest(){
		Order order = new Order();
		while (true) {
			order.useOrder();			
		}
	}
}
