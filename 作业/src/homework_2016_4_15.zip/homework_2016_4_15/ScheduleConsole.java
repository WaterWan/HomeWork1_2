package homework_2016_4_15;

import java.util.Scanner;

public class ScheduleConsole {
	public static String getOrder(){
		Scanner scanner = new Scanner(System.in);
		String order = scanner.nextLine();
		
		return order;
	}
}
